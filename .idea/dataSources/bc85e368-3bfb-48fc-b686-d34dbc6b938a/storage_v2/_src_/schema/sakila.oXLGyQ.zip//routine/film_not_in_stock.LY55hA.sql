create procedure film_not_in_stock(IN p_film_id INT(10), IN p_store_id INT(10), IN p_film_count INT(10))
BEGIN
     SELECT inventory_id
     FROM inventory
     WHERE film_id = p_film_id
     AND store_id = p_store_id
     AND NOT inventory_in_stock(inventory_id);

     SELECT FOUND_ROWS() INTO p_film_count;
END;

